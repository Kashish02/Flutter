/// Event Object for api calls
class EventObject {
  int id;
  String response;
  int statusCode;

  EventObject({required this.id, required this.response,required this.statusCode});
}
