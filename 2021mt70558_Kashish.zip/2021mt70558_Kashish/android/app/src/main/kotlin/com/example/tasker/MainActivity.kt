package com.example.tasker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
